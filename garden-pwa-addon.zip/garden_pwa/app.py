"""
Veg Garden PWA — public no-login dashboard with PIN gate.

Routes:
  GET /            -> if no auth cookie -> /pin ; else dashboard
  GET /pin         -> PIN entry form
  POST /pin        -> validate + set cookie
  GET /api/state   -> JSON state (auth cookie required)
  POST /api/start  -> trigger 5-min drip
  POST /api/stop   -> stop drip
  GET /manifest.json, /icons/*  -> PWA assets
"""
import os, json, hmac, hashlib, time, secrets, datetime as dt
from urllib import request as ur
from urllib.error import HTTPError, URLError
from fastapi import FastAPI, Request, Response, Form, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn

# ===== CONFIG =====
# Inside HAOS addon: HA_URL=http://supervisor/core, HA_TOKEN=${SUPERVISOR_TOKEN}
# Standalone: set both manually
HA_URL    = os.environ.get("HA_URL", "http://supervisor/core")
HA_TOKEN  = os.environ.get("HA_TOKEN") or os.environ.get("SUPERVISOR_TOKEN") or ""
if not HA_TOKEN:
    raise SystemExit("HA_TOKEN or SUPERVISOR_TOKEN must be set")
APP_PIN   = os.environ.get("APP_PIN", "0000")
COOKIE_SECRET = os.environ.get("COOKIE_SECRET", "change-me-please-32bytes-random")
COOKIE_NAME = "veg_auth"
COOKIE_TTL  = 365 * 24 * 3600  # 1 year

# Freeze threshold (°C)
FREEZE_AT = float(os.environ.get("FREEZE_AT", "1.0"))

# Entity IDs (must match HA)
E_MOIST  = "sensor.veg_soil_moisture"
E_TEMP   = "sensor.veg_soil_temperature"
E_BAT    = "sensor.veg_soil_battery"
E_VALVE  = "valve.veg_garden"
E_WATER  = "binary_sensor.veg_garden_watering"
E_REMAIN = "sensor.veg_garden_remaining_watering_time"
E_NEXT   = "sensor.veg_garden_next_cycle"
E_DAILY  = "sensor.veg_garden_daily_active_watering_time"
E_MANUAL = "switch.veg_garden_manual_watering"
E_RAIN   = "binary_sensor.allview_sprinklers_rain_sensor"
E_WEATHER= "weather.forecast_home"

# ===== HA CLIENT =====
def ha(method: str, path: str, body=None):
    req = ur.Request(
        f"{HA_URL}/api{path}",
        method=method,
        headers={"Authorization": f"Bearer {HA_TOKEN}", "Content-Type": "application/json"},
        data=json.dumps(body).encode() if body is not None else None,
    )
    try:
        return json.loads(ur.urlopen(req, timeout=10).read())
    except HTTPError as e:
        return {"error": f"http {e.code}", "body": e.read().decode()[:300]}
    except URLError as e:
        return {"error": f"url {e.reason}"}

def get_state(eid: str):
    r = ha("GET", f"/states/{eid}")
    return r if isinstance(r, dict) else None

def call_service(domain: str, service: str, payload: dict):
    return ha("POST", f"/services/{domain}/{service}", payload)

# ===== AUTH (PIN cookie) =====
def make_cookie(value: str) -> str:
    sig = hmac.new(COOKIE_SECRET.encode(), value.encode(), hashlib.sha256).hexdigest()
    return f"{value}.{sig}"

def verify_cookie(cookie: str) -> bool:
    if not cookie or "." not in cookie:
        return False
    value, sig = cookie.rsplit(".", 1)
    expected = hmac.new(COOKIE_SECRET.encode(), value.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        ts = int(value.split("|")[0])
    except Exception:
        return False
    return (time.time() - ts) < COOKIE_TTL

def is_authed(request: Request) -> bool:
    return verify_cookie(request.cookies.get(COOKIE_NAME, ""))

# ===== APP =====
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

@app.get("/manifest.webmanifest")
def manifest():
    return JSONResponse({
        "name": "Veg Garden",
        "short_name": "Garden",
        "start_url": "/garden/",
        "scope": "/garden/",
        "display": "standalone",
        "orientation": "portrait",
        "background_color": "#0b1117",
        "theme_color": "#0b1117",
        "icons": [
            {"src": "/garden/static/icon-192.png", "sizes": "192x192", "type": "image/png"},
            {"src": "/garden/static/icon-512.png", "sizes": "512x512", "type": "image/png"},
        ],
    })

@app.get("/pin", response_class=HTMLResponse)
def pin_page(request: Request, error: str = ""):
    return templates.TemplateResponse("pin.html", {"request": request, "error": error})

@app.post("/pin")
def pin_submit(response: Response, pin: str = Form(...)):
    if pin.strip() != APP_PIN:
        return RedirectResponse(url="/garden/pin?error=1", status_code=303)
    value = f"{int(time.time())}|{secrets.token_hex(8)}"
    resp = RedirectResponse(url="/garden/", status_code=303)
    resp.set_cookie(COOKIE_NAME, make_cookie(value),
        max_age=COOKIE_TTL, httponly=True, samesite="lax", secure=True, path="/garden")
    return resp

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    if not is_authed(request):
        return RedirectResponse(url="/garden/pin", status_code=303)
    return templates.TemplateResponse("dashboard.html", {"request": request})

# ===== state assembly =====
def humanize_age(iso: str) -> str:
    if not iso: return "never"
    try:
        t = dt.datetime.fromisoformat(iso.replace("Z","+00:00"))
    except Exception:
        return iso
    delta = dt.datetime.now(dt.timezone.utc) - t
    s = int(delta.total_seconds())
    if s < 60:   return f"{s}s ago"
    if s < 3600: return f"{s//60}m ago"
    if s < 86400:return f"{s//3600}h ago"
    return f"{s//86400}d ago"

def fmt_local(iso: str) -> str:
    if not iso: return ""
    try:
        t = dt.datetime.fromisoformat(iso.replace("Z","+00:00"))
        # Server timezone (node-b) — for accuracy we'd want client tz, but close enough
        return t.astimezone().strftime("%a %-I:%M %p")
    except Exception:
        return iso

@app.get("/api/state")
def api_state(request: Request):
    if not is_authed(request):
        raise HTTPException(401)
    moist = get_state(E_MOIST) or {}
    temp  = get_state(E_TEMP) or {}
    bat   = get_state(E_BAT) or {}
    valve = get_state(E_VALVE) or {}
    watering = get_state(E_WATER) or {}
    remain = get_state(E_REMAIN) or {}
    rain   = get_state(E_RAIN) or {}
    weather= get_state(E_WEATHER) or {}

    # Last watered: use last_changed of binary_sensor.veg_garden_watering when last "on"
    # Pull /history for last 7 days
    since = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=7)).isoformat()
    hist = ha("GET", f"/history/period/{since}?filter_entity_id={E_WATER}&minimal_response")
    last_on = None
    last_off = None
    if isinstance(hist, list) and hist and isinstance(hist[0], list):
        for ev in hist[0]:
            if ev.get("state") == "on":
                last_on = ev.get("last_changed", last_on)
            elif ev.get("state") == "off" and last_on:
                last_off = ev.get("last_changed", last_off)

    moist_v = float(moist.get("state") or 0)
    temp_v  = float(temp.get("state") or 0)
    is_watering = watering.get("state") == "on"
    valve_state = valve.get("state","unknown")

    # Status pill
    if is_watering:
        rem = remain.get("state","?")
        status_text = f"💧 Watering — {rem} min left"
        status_kind = "watering"
    elif moist_v >= 80:
        status_text = "Soil moist — happy"
        status_kind = "ok"
    elif moist_v >= 60:
        status_text = "Soil OK"
        status_kind = "ok"
    else:
        status_text = "Thirsty 🥺"
        status_kind = "thirsty"

    # Freeze warning
    freeze_alert = temp_v <= FREEZE_AT

    # Weather
    w_attrs = weather.get("attributes", {}) or {}
    forecast = []
    # Try to fetch a forecast via service call (modern HA)
    fc = ha("POST","/services/weather/get_forecasts?return_response=true",
            {"entity_id": E_WEATHER, "type": "daily"})
    try:
        days = fc["service_response"][E_WEATHER]["forecast"][:3]
        for d in days:
            forecast.append({
                "date": d.get("datetime","")[:10],
                "low":  d.get("templow"),
                "high": d.get("temperature"),
                "precip": d.get("precipitation"),
                "precip_prob": d.get("precipitation_probability"),
                "cond": d.get("condition"),
            })
    except Exception:
        forecast = []

    return {
        "moisture": round(moist_v, 1),
        "temperature": round(temp_v, 1),
        "battery": int(float(bat.get("state") or 0)),
        "valve": valve_state,
        "is_watering": is_watering,
        "remaining_min": remain.get("state","0"),
        "status_text": status_text,
        "status_kind": status_kind,
        "freeze_alert": freeze_alert,
        "freeze_threshold": FREEZE_AT,
        "last_watered_iso": last_off or last_on,
        "last_watered_age": humanize_age(last_off or last_on),
        "last_watered_local": fmt_local(last_off or last_on),
        "rain_outdoor": rain.get("state") == "on",
        "weather_now": {
            "condition": weather.get("state"),
            "temperature": w_attrs.get("temperature"),
            "humidity": w_attrs.get("humidity"),
        },
        "forecast": forecast,
    }

# ===== 24h history =====
def _parse_dt(iso: str):
    if not iso: return None
    try: return dt.datetime.fromisoformat(iso.replace("Z","+00:00"))
    except Exception: return None

def _series_24h(eid: str, sample_n: int = 24):
    """Fetch last 24h of states for entity. Return {min,max,first,last,points:[(t,v)],count}."""
    since = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=24)).isoformat()
    hist = ha("GET", f"/history/period/{since}?filter_entity_id={eid}&minimal_response")
    pts = []
    if isinstance(hist, list) and hist and isinstance(hist[0], list):
        for ev in hist[0]:
            v = ev.get("state")
            if v in (None, "unknown", "unavailable", ""): continue
            try: v = float(v)
            except (TypeError, ValueError): continue
            t = _parse_dt(ev.get("last_changed") or ev.get("last_updated"))
            if t is None: continue
            pts.append((t, v))
    if not pts:
        return {"min": None, "max": None, "first": None, "last": None, "points": [], "count": 0}
    vals = [v for _, v in pts]
    # Downsample evenly for sparkline
    if len(pts) > sample_n:
        step = len(pts) / sample_n
        sampled = [pts[int(i*step)] for i in range(sample_n)]
        if sampled[-1] != pts[-1]: sampled.append(pts[-1])
        spark_pts = sampled
    else:
        spark_pts = pts
    return {
        "min": round(min(vals), 1),
        "max": round(max(vals), 1),
        "first": round(pts[0][1], 1),
        "last": round(pts[-1][1], 1),
        "points": [round(v, 1) for _, v in spark_pts],
        "count": len(pts),
    }

@app.get("/api/history")
def api_history(request: Request):
    if not is_authed(request):
        raise HTTPException(401)
    moist24 = _series_24h(E_MOIST)
    temp24  = _series_24h(E_TEMP)

    # Watering events in last 24h: count on->off transitions and total minutes
    since = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=24)).isoformat()
    hist = ha("GET", f"/history/period/{since}?filter_entity_id={E_WATER}&minimal_response")
    total_min = 0.0
    events = 0
    last_on = None
    if isinstance(hist, list) and hist and isinstance(hist[0], list):
        for ev in hist[0]:
            st = ev.get("state")
            t = _parse_dt(ev.get("last_changed") or ev.get("last_updated"))
            if t is None: continue
            if st == "on":
                last_on = t
            elif st == "off" and last_on:
                total_min += (t - last_on).total_seconds() / 60.0
                events += 1
                last_on = None
        # If still on at the end of window
        if last_on:
            total_min += (dt.datetime.now(dt.timezone.utc) - last_on).total_seconds() / 60.0
            events += 1

    # Rain in last 24h
    rain_hist = ha("GET", f"/history/period/{since}?filter_entity_id={E_RAIN}&minimal_response")
    rain_detected = False
    if isinstance(rain_hist, list) and rain_hist and isinstance(rain_hist[0], list):
        rain_detected = any(ev.get("state") == "on" for ev in rain_hist[0])

    # Trend label
    def trend(s):
        if s["first"] is None or s["last"] is None: return "flat"
        diff = s["last"] - s["first"]
        if abs(diff) < 1.0: return "flat"
        return "up" if diff > 0 else "down"

    return {
        "moisture": {**moist24, "trend": trend(moist24)},
        "temperature": {**temp24, "trend": trend(temp24)},
        "watering": {
            "total_minutes": round(total_min, 1),
            "events": events,
        },
        "rain_detected": rain_detected,
    }

@app.post("/api/start")
def api_start(request: Request):
    if not is_authed(request):
        raise HTTPException(401)
    r = call_service("switch","turn_on",{"entity_id": E_MANUAL})
    return {"ok": "error" not in str(r), "result": r}

@app.post("/api/stop")
def api_stop(request: Request):
    if not is_authed(request):
        raise HTTPException(401)
    r = call_service("switch","turn_off",{"entity_id": E_MANUAL})
    return {"ok": "error" not in str(r), "result": r}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8090")), root_path="/garden")
