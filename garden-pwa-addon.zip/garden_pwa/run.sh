#!/usr/bin/with-contenv bashio
set -e

export APP_PIN="$(bashio::config 'pin')"
export FREEZE_AT="$(bashio::config 'freeze_at')"
export COOKIE_SECRET="$(bashio::config 'cookie_secret')"

# Auto-generate cookie secret if blank
if [ -z "$COOKIE_SECRET" ]; then
  export COOKIE_SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  bashio::log.warning "cookie_secret was empty; generated random one (will rotate on restart). Set one in addon config to persist."
fi

# Use the supervisor-injected HA API for the addon — same VM, no token needed
export HA_URL="http://supervisor/core"
export HA_TOKEN="${SUPERVISOR_TOKEN}"
export PORT=8090

bashio::log.info "Starting Veg Garden PWA on :8090 (PIN=${APP_PIN})"
exec python3 -m uvicorn app:app --host 0.0.0.0 --port 8090 --root-path /garden
