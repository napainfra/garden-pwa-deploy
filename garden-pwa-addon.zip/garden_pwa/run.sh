#!/bin/sh
set -e

OPTS=/data/options.json

# Read config from supervisor-supplied options.json with jq
APP_PIN=$(jq -r '.pin // "8899"' "$OPTS")
FREEZE_AT=$(jq -r '.freeze_at // 1.0' "$OPTS")
COOKIE_SECRET=$(jq -r '.cookie_secret // ""' "$OPTS")

# Auto-generate cookie secret if blank (note: rotates on restart unless set in config)
if [ -z "$COOKIE_SECRET" ] || [ "$COOKIE_SECRET" = "null" ]; then
  COOKIE_SECRET=$(python3 -c 'import secrets; print(secrets.token_hex(32))')
  echo "[garden_pwa] cookie_secret blank; generated ephemeral one"
fi

export APP_PIN
export FREEZE_AT
export COOKIE_SECRET
export HA_URL="http://supervisor/core"
export HA_TOKEN="${SUPERVISOR_TOKEN}"
export PORT=8090

echo "[garden_pwa] Starting Veg Garden PWA on :8090 (PIN=${APP_PIN}, freeze=${FREEZE_AT})"
exec python3 -m uvicorn app:app --host 0.0.0.0 --port 8090 --root-path /garden
